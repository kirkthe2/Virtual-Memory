//
//  virt_mem.c
//  virt_mem
//
//  Created by William McCarthy on 3/23/19.
//  Copyright © 2019 William McCarthy. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define ARGC_ERROR 1
#define FILE_ERROR 2
#define READ_ERROR 3
#define BUFLEN 256
#define FRAME_SIZE  256
struct frame_list{
	char free_frame[FRAME_SIZE][FRAME_SIZE];
	int start_frame;
};

struct TLB {
	unsigned int pages[FRAME_SIZE];
	unsigned int frames[FRAME_SIZE];
	int current_total;
	int begin_frame;
};

struct pTable{
	unsigned int pIndex[FRAME_SIZE];
	unsigned int validBit[FRAME_SIZE];
	int next_frame;
};

struct frame_list fList;
struct TLB tlb;
struct pTable pageTab;
int nread;
  
//-------------------------------------------------------------------
unsigned int getpage(size_t x) { return (0xff00 & x) >> 8; }
unsigned int getoffset(unsigned int x) { return (0xff & x); }

void getpage_offset(unsigned int x) {
  unsigned int page = getpage(x);
  unsigned int offset = getoffset(x);
  printf("x is: %u, page: %u, offset: %u, address: %u, paddress: %u\n", x, page, offset,
         (page << 8) | getoffset(x), page * 256 + offset);
}

int checkTLB(int page)
{
	int frame = -1;
	for(int i = 0; i < tlb.current_total; i++)
	{
		if(tlb.pages[(tlb.begin_frame + i)%FRAME_SIZE] == page)
		{
			frame = tlb.frames[(tlb.begin_frame + i)%FRAME_SIZE];
			break;
		}
	}
	return frame;
}


void update_table(unsigned int page, int frame)
{
	pageTab.pIndex[page] = frame;
	++pageTab.next_frame;
}

void update_tlb(int page, int frame)
{
	if(tlb.current_total == FRAME_SIZE)
	{
		tlb.pages[tlb.begin_frame] = page;
		tlb.frames[tlb.begin_frame] = frame;
		tlb.begin_frame = (tlb.begin_frame + 1)%FRAME_SIZE;
	}
	else
	{
		tlb.pages[tlb.current_total] = page;
		tlb.frames[tlb.current_total] = frame;
		tlb.current_total++;
	}
}

int checkPTable(unsigned int page, unsigned int offset,unsigned int frame, FILE* disk_file, char* phys_mem)
{
        static int pageFault = 0;
	if(pageTab.pIndex[page] == -1)
	{
		pageFault++;
		frame = pageTab.next_frame;
		char *p = phys_mem + frame * FRAME_SIZE;
		fseek(disk_file, page * FRAME_SIZE, SEEK_SET);
		if((nread = fread(p, sizeof(char), FRAME_SIZE, disk_file))<FRAME_SIZE)
		{
			fprintf(stderr,"\n");
			exit(READ_ERROR);
		}
		update_table(page, frame);
	}
	else
	{
		frame = pageTab.pIndex[page];
	}
	update_tlb(page, frame);
	return pageFault;
}

int main(int argc, const char * argv[]) {
  FILE* fadd = fopen("addresses.txt", "r");
  if (fadd == NULL) { fprintf(stderr, "Could not open file: 'addresses.txt'\n");  exit(FILE_ERROR);  }
  FILE* fcorr = fopen("correct.txt", "r");
  if (fcorr == NULL) { fprintf(stderr, "Could not open file: 'correct.txt'\n");  exit(FILE_ERROR);  }
  FILE *fptr = fopen("BACKING_STORE.bin", "rb");  
  if (fptr == NULL) { fprintf(stderr, "Could not open file: 'BACKING_STORE.bin'\n");  exit(FILE_ERROR);  }
  char buf[BUFLEN];
  char* phys_mem = (char*) malloc(FRAME_SIZE * sizeof(char));
  unsigned int page, offset, physical_add, frame = 0;
  unsigned int logic_add;                  // read from file address.txt
  unsigned int virt_add, phys_add, corr_value;  // read from file correct.txt
  fList.start_frame = 0;
  tlb.current_total = 0;
  tlb.begin_frame = 0;
  pageTab.next_frame = 0;
  unsigned int value;
  int tlbHits = 0;
  int pageFaults = 0;
  int addressesProcessed = 0;
      // not quite correct -- should search page table before creating a new entry
      //   e.g., address # 25 from addresses.txt will fail the assertion
      // TODO:  add page table code
	for(int i = 0; i<FRAME_SIZE; i++)
	{
		pageTab.pIndex[i] = -1;
		pageTab.validBit[i] = 0;
	}
      // TODO:  add TLB code
	
  while (frame < 25) {
    addressesProcessed++;
    fscanf(fcorr, "%s %s %d %s %s %d %s %d", buf, buf, &virt_add,
           buf, buf, &phys_add, buf, &corr_value);  // read from file correct.txt

    fscanf(fadd, "%d", &logic_add);  // read from file address.txt
    page = getpage(logic_add);
    offset = getoffset(logic_add);
    /*frame = checkTLB(page);
    if(frame == -1)
    {*/
    	pageFaults = checkPTable(page, offset,frame, fptr, phys_mem);
	//frame = checkTLB(page);
    /*}
    else
    {
	tlbHits++;
    }*/
    physical_add = frame++ * FRAME_SIZE + offset;
    value = *(phys_mem + physical_add);
    assert(physical_add == phys_add);
    assert(value == corr_value);
	
    // todo: read BINARY_STORE and confirm value matches read value from correct.txt
    printf("logical: %5u (page:%3u, offset:%3u) ---> physical: %5u -- passed\n", logic_add, page, offset, physical_add);
    if (frame % 5 == 0) { printf("\n"); }

  }
  fclose(fcorr);
  fclose(fadd);
  free(phys_mem);
  double faultRate = (double) pageFaults / addressesProcessed;
  double tlbHitRate = (double) tlbHits / addressesProcessed;
  printf("Page-fault Rate: %f, TLB hit rate: %f\n",faultRate, tlbHitRate);
  printf("ALL logical ---> physical assertions PASSED!\n");
  printf("!!! This doesn't work passed entry 24 in correct.txt, because of a duplicate page table entry\n");
  printf("--- you have to implement the PTE and TLB part of this code\n");
  printf("\n\t\t...done.\n");
  return 0;
}
